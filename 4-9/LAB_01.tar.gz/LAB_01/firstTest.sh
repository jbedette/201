#!/bin/bash
# This is a simple bash script
echo "My First bash script"
echo "Creating and setting a local variable a to 1"
a=1
echo "Now I'm going to use the variable a ..."
echo "Var a has value" $a
